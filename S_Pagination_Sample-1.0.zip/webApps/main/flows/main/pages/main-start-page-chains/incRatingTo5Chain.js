define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class incRatingTo5Chain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      try {
        $("#busyDialog")[0].open();
        await $page.functions.setRatingToSelectedRows(5, $page.variables.selectedRows);

        await Actions.resetVariables(context, {
          variables: [
            '$variables.selectedRows',
          ],
        });
        $("#busyDialog")[0].close();
      }
      catch (e) {
        $("#busyDialog")[0].close();
        await Actions.fireNotificationEvent(context, {
          summary: 'Change Rating to Five',
          message: e,
        });
      }
    }
  }

  return incRatingTo5Chain;
});
