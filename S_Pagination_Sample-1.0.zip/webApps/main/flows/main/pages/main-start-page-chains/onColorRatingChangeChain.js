define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojmodel'
], (
  ActionChain,
  Actions,
  ActionUtils,
  ModelClass
) => {
  'use strict';

  class onColorRatingChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.previousValue
     * @param {any} params.value
     * @param {string} params.updatedFrom
     * @param {any} params.key
     * @param {number} params.index
     * @param {any} params.current
     */
    async run(context, { event, previousValue, value, updatedFrom, key, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      try {
        $("#busyDialog")[0].open();
        let rowIndex = index;
        let ratingVal = value;

        let model = $(".oj-table")[0].data.dataProvider.collection.get(key);
        let newModel = new ModelClass.Model(model.attributes);
        newModel.set("rating", ratingVal);
        $(".oj-table")[0].data.dataProvider.collection.add(newModel, { at: rowIndex, merge: true });
        $("#busyDialog")[0].close();
      }
      catch (e) {
        console.log(e);
        $("#busyDialog")[0].close();
        await Actions.fireNotificationEvent(context, {
          summary: 'Update Rating',
          message: e,
        });
      }
    }
  }

  return onColorRatingChangeChain;
});
