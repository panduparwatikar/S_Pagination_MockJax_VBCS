define(['ojs/ojcontext', 'knockout', 'vb/helpers/rest', 'ojs/ojmodel', 'ojs/ojpagingdataproviderview', 'ojs/ojcollectiondataprovider', 'resources/js/jquery.mockjax.min'], (Context, ko, REST, ModelClass, PagingDataProviderView, CollectionDataProvider) => {
  'use strict';

  Context.getPageContext().getBusyContext().whenReady()
    .then(
      (data) => $("#busyDiv").fadeOut(200, () => {
        $("#pageContent").fadeIn(300);
      }))
    .catch(err => {
      $("#busyDiv").text("ERROR;Could not start the application");
      console.log("ERROR ", err)
    });

  var self;

  class PageModule {
    constructor() {
      self = this;

      self = this;
      self.limit = ko.observable(50);
      self.offset = ko.observable(0);
      self.serviceURL = '/api/data/photos?_start=' + self.offset() + '&_limit=' + self.limit();

      $.mockjax({
        url: /^\/api\/data\/photos\?_start=[0-9]+&_limit=[0-9]+(?:&limit=[0-9]+&offset=[0-9]+&totalResults=true)?$/,
        type: 'GET',
        response: function (settings, done) {
          var mockSelf = this;
          return (async function () {
            let queryParams = { "_start": self.offset(), "_limit": self.limit() };
            let rest = REST.get('getPhotos/photos').parameters(queryParams);
            let response = await rest.fetch();
            response.hasMore = true;
            mockSelf.responseText = response;
            done();
          })();
        }
      });

      self.parsePhoto = (response) => {
        return { ...response, "color": (Math.random() * 0xFFFFFF << 0).toString(16).padStart(6, '0'), "rating": Math.floor(Math.random() * (5 - 1 + 1)) + 1 };
      };



      self.photoModel = ModelClass.Model.extend({
        urlRoot: self.serviceURL,
        parse: self.parsePhoto,
        idAttribute: 'id'
      });

      self.myPhoto = new self.photoModel();
      self.photoCollection = ModelClass.Collection.extend({
        url: self.serviceURL,
        model: self.myPhoto
      });

      self.collection = new self.photoCollection();

      //Commenting below will make the Collection Non-Virtual
      //Non-Virtual means the numbers of rows are alreayd knows
      //CRUD Operations are all possible in non-virtual collections only
      //In Virtual collections Create, Update and Delete are not easily supported

      // self.collection.customPagingOptions = (response) => {
      //   return {
      //     totalResults: 5000,
      //     hasMore: true,
      //     fetchSize: 100
      //   }
      // }

      //Below function is called internally by the Collection API
      //The function is called when the last page is clicked, and then
      //the collection API calls the below function to increase the offset and get the new URL
      //This function is called only in Virtual Collections
      //Commenting the below as we now only have a Non-Virtual Collection
      // self.collection.customURL = (oprtn, collctn, optns) => {
      //   if (oprtn == 'read') {
      //     console.log("Operation read");
      //     console.log("OPTIONS ARE ", optns)
      //     if (optns.startIndex)
      //       self.offset(optns.startIndex);
      //     self.serviceURL = '/api/data/photos?_start=' + self.offset() + '&_limit=' + self.limit();
      //     return { 'url': self.serviceURL, 'type': 'GET' };
      //   }
      //   return null;
      // };

      self.cdp = new CollectionDataProvider(self.collection);
      self.pdp = new PagingDataProviderView(self.cdp);
      self.pdp.addEventListener("PAGE", (event) => {
        console.log("PAGE EVENT ", event);
        if (event.detail.page == (self.pdp.getPageCount() - 1)) {
          self.offset(self.offset() + self.limit());
          console.log("OFFSET IS ", self.offset());
          self.limit(self.limit() + 1);
          self.serviceURL = '/api/data/photos?_start=' + self.offset() + '&_limit=' + self.limit();
          //$(".oj-table")[0].data.dataProvider.collection.fetch({add:true});

          $.ajax({
            url: self.serviceURL,
            type: 'GET'
          }).done((resp) => {
            console.log("RESP IS ", resp);
            resp.body.forEach((row, index) => {
              let newModel = new ModelClass.Model({
                ...row,
                "color": (Math.random() * 0xFFFFFF << 0).toString(16).padStart(6, '0'),
                "rating": Math.floor(Math.random() * (5 - 1 + 1)) + 1
              });

              $(".oj-table")[0].data.dataProvider.collection.add(newModel, { at: self.offset() + index });
            });
          });
        }
      })

      self.columns = [{ "field": "title", "headerText": "Title", "sortable": "disabled" },
      { "field": "color", "template": "photoImg", "headerText": "Image", "sortable": "disabled" },
      { "field": "rating", "template": "colorRating", "headerText": "Rating", "sortable": "disabled" },
      { "template": "deleteRow", "headerText": "Delete", "sortable": "disabled" }];
    }
  }

  PageModule.prototype.getData = () => {
    $.ajax({
      url: self.serviceURL,
      type: 'GET'
    }).done((resp) => {
      console.log("RESPONSE IS ", resp);
    });
  };

  PageModule.prototype.deleteRow = (row) => {
    let model = $(".oj-table")[0].data.dataProvider.collection.get(row.key);
    $(".oj-table")[0].data.dataProvider.collection.remove(model);
  }

  PageModule.prototype.addRow = () => {
    let newModel = new ModelClass.Model({
      "almbumId": 1,
      "id": new Date().getTime(),
      "title": "New Photo",
      "thumbnailUrl": "",
      "color": (Math.random() * 0xFFFFFF << 0).toString(16).padStart(6, '0')
    });

    let startItemIndex = $(".oj-table")[0].data.getStartItemIndex();
    $(".oj-table")[0].data.dataProvider.collection.add(newModel, { at: startItemIndex });
  };

  PageModule.prototype.setRatingToSelectedRows = async (ratingVal, selectedKeys) => {
    try {
      if (selectedKeys) {
        console.log("Selected Keys are ", selectedKeys);
        let rows = selectedKeys.keys.all ? $(".oj-table")[0].data.dataProvider.collection.models : await self.cdp.fetchByKeys(selectedKeys.keys);
        if (rows) {
          if (rows.results) {
            for await (const [key, value] of rows.results) {
              await PageModule.prototype.updateRowRating(key, ratingVal);
            }
          }
          else {
            for await (let modelRow of rows) {
              await PageModule.prototype.updateRowRating(modelRow.attributes.id, ratingVal);
            }
          }
        }
        else {
          throw "Rows not identified from selected rows variables";
        }
      }
    }
    catch (e) {
      console.log(e);
      throw e;
    }
  };

  PageModule.prototype.updateRowRating = async (rowKey, ratingVal) => {
    try {
      let model = self.collection.get(rowKey);
      let newModel = new ModelClass.Model(model.attributes);
      newModel.set("rating", ratingVal);
      let modelIndex = $(".oj-table")[0].data.dataProvider.collection.models.findIndex(modelRow => modelRow.id == rowKey);
      if (modelIndex > -1) {
        //$(".oj-table")[0].data.dataProvider.collection.remove(model,{silent:true});
        $(".oj-table")[0].data.dataProvider.collection.add(newModel, { at: modelIndex, merge: true });
      }
    }
    catch (e) {
      throw e;
    }
  };

  return PageModule;
});
